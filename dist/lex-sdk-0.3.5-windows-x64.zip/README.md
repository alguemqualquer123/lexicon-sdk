# Lexicon SDK

Self-contained LexiconLang toolchain kit.

- `bin/` — ONE `lex` compiler + toolchain binary, plus `lex-<tool>`
  launcher shims (`lex-run`, `lex-lsp`, … — a few hundred bytes each, all
  delegating to that single binary).
- `lib/std/` — standard-library Lex sources (all pass `lex check`).
- `templates/` — `lex new` starters (`default`, `api`, `service`, `plugin`, `gui`).
- `examples/` — runnable samples (`lex run examples/hello.lex`).
- `docs/` — CLI reference, stdlib reference, embedding contract.
- `scripts/` — `activate.ps1` / `activate.sh` put `bin/` on PATH.

Quick start (PowerShell): `. scripts/activate.ps1; lex version`
Quick start (sh): `. scripts/activate.sh && lex version`

Flavours: `bin/lex` is either the full build (`lex gui` works) or the
~3.5 MB mini runtime (`lex sdk info` reports which).
